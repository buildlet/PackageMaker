﻿BUILDLet PackageMaker Toolkit Readme サンプル
Copyright (C) 2015-2017 BUILDLet All rights reserved.

ダミー パッケージ 2.1.0.0
2017年3月29日

ドライバー バージョン (x86) 1.0.32.0
ドライバー バージョン (x64) 1.0.64.0

これは Readme のダミーファイルです。
